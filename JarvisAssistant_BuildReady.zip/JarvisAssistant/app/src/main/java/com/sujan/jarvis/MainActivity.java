package com.sujan.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView status, response, command; Button mic; SpeechRecognizer recognizer; TextToSpeech tts;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status); response=findViewById(R.id.response); command=findViewById(R.id.command); mic=findViewById(R.id.mic);
        tts=new TextToSpeech(this, s -> { });
        mic.setOnClickListener(v -> startListening());
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
    }
    void startListening(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ speak("Speech recognition is not available on this phone."); return; }
        status.setText("JARVIS AI  •  LISTENING"); command.setText("I'm listening…");
        if(recognizer!=null) recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
            public void onError(int e){ status.setText("JARVIS AI  •  ONLINE"); command.setText("Tap the orb and speak"); }
            public void onResults(Bundle b){ ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) handle(a.get(0)); }
            public void onPartialResults(Bundle b){} public void onEvent(int t, Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); recognizer.startListening(i);
    }
    void handle(String raw){
        String q=raw.toLowerCase(Locale.ROOT).trim(); command.setText(raw); status.setText("JARVIS AI  •  PROCESSING");
        if(q.contains("youtube")){ open("https://www.youtube.com"); reply("Opening YouTube."); return; }
        if(q.contains("google")){ open("https://www.google.com"); reply("Opening Google."); return; }
        if(q.contains("chrome")){ try{startActivity(getPackageManager().getLaunchIntentForPackage("com.android.chrome")); reply("Opening Chrome.");}catch(Exception e){reply("Chrome is not available.");} return; }
        if(q.contains("settings")){ startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); reply("Opening settings."); return; }
        if(q.contains("time")){ String s=new java.text.SimpleDateFormat("h:mm a",Locale.getDefault()).format(new Date()); reply("The time is "+s+"."); return; }
        if(q.contains("hello")||q.contains("hi")){ reply("Hello. Systems are ready."); return; }
        reply("I heard: "+raw+". The advanced AI connector can be attached here for full conversational intelligence.");
    }
    void open(String u){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception ignored){} }
    void reply(String s){ status.setText("JARVIS AI  •  ONLINE"); response.setText(s); speak(s); }
    void speak(String s){ if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis_reply"); }
    @Override protected void onDestroy(){ if(recognizer!=null)recognizer.destroy(); if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}
