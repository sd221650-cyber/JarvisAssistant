# JARVIS Assistant — phone-friendly cloud build

This project includes a GitHub Actions workflow that can build a debug APK in the cloud.

1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Run **Build JARVIS APK** (or push to `main`).
4. Open the completed run and download the **JARVIS-debug-apk** artifact.

No phone permissions or passwords need to be shared with ChatGPT.
